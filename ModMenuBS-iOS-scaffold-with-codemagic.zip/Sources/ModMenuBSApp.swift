import SwiftUI

@main
struct ModMenuBSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
